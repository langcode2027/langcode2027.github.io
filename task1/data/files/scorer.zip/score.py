"""LangCode 2027 Shared Task 1 scorer for CodaBench (spec v15, sections 6-9).

usage: python3 score.py [INPUT_DIR [OUTPUT_DIR]]        (defaults: /app/input /app/output)
       python3 score.py --check SUBMISSION [PUBLIC_JSONL]  (format check only; SUBMISSION is a zip, folder or .jsonl)
  INPUT_DIR/ref: reference.jsonl (one task per line) and phase.json
  INPUT_DIR/res: the unzipped submission, holding submission.jsonl
Writes OUTPUT_DIR/scores.json (the same keys in every phase, so each phase's leaderboard shows one set
of columns) and, when phase.json has "detailed_results": true, detailed_results.html.

A submission that breaks the format rules is rejected as a whole: the scorer prints the reason and
exits with status 1, so CodaBench marks it failed. The log never shows test data or scores.

Limits per task: 1 s CPU time (the binding limit, little affected by machine load), 3 s wall clock,
512 MB memory (1 GB of address space for Node, whose V8 reserves more than it uses; its heap is capped
at 512 MB), one 1 MB results file and no other files. The CPU limit is strict: the process is killed
at 1 s and the task is not rerun, so infinite loops cost 1 s each. Only wall-clock timeouts (a blocked
solution or a busy machine) are rerun once with half the workers, when there are at most 100 of them
and time is left. The whole run has a time budget (default
480 s, under CodaBench's 600 s): tasks not started by then count as timeouts, so a submission full of
slow solutions still finishes and is scored.

On Linux every solution runs under a seccomp filter (lc_sandbox.py) that refuses new processes,
sockets, signals to other processes, changes to file modes or owners, and system-level calls, so a
solution cannot fork-bomb, reach the network, kill the scorer or reopen the reference data. C is
compiled without the filter but with time and memory limits.

Each task runs in its own temporary directory, in its own process group. Run as root with the right to
switch users, every worker drops to its own unprivileged uid, the reference and output folders are
closed to those uids, and process and memory limits apply. CodaBench's containers run as root without
that right (found on 2026-10-27): solutions then run as root with the time, memory and file-size limits,
and every stray process is killed before the scores are written. Run as a normal user (local checks),
only the time and file-size limits apply. Limits can be changed with LC_* environment variables.
"""
import concurrent.futures as cf
import html, json, multiprocessing as mp, os, re, resource, shutil, signal, subprocess, sys, tempfile, time, zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lc_harness as H
try:
    import lc_sandbox
except Exception:          # not Linux, or no ctypes
    lc_sandbox = None

CPU = int(os.environ.get("LC_CPU", "1"))                       # CPU seconds per task: the real time limit
TIMEOUT = float(os.environ.get("LC_TIMEOUT", "3.0"))          # wall clock per task, for solutions that block
RETRY_MAX = int(os.environ.get("LC_RETRY_MAX", "100"))         # timeouts rerun once, if there are this many or fewer
MEM_MB = int(os.environ.get("LC_MEM_MB", "512"))
NODE_AS_MB = int(os.environ.get("LC_NODE_AS_MB", "1024"))
COMPILE_MEM_MB = int(os.environ.get("LC_COMPILE_MEM_MB", "1024"))
BUDGET = float(os.environ.get("LC_BUDGET", "480"))             # seconds for the whole submission
NPROC = int(os.environ.get("LC_NPROC", "32"))                  # processes and threads per worker uid
COMPILE_TIMEOUT = 10.0
MAX_SOLUTION = 20 * 1024                                       # bytes, UTF-8
WORKERS = int(os.environ.get("LC_WORKERS", str(min(8, os.cpu_count() or 1))))
UID_BASE = int(os.environ.get("LC_UID_BASE", "61000"))
ROOT = hasattr(os, "geteuid") and os.geteuid() == 0
LINUX = sys.platform.startswith("linux")
PATH = ":".join(p for p in ("/opt/homebrew/bin", "/usr/local/bin", "/usr/bin", "/bin") if os.path.isdir(p))
OUTCOMES = ["passed", "wrong answer", "runtime error", "timeout", "compile error", "rejected", "missing"]
FENCE = re.compile(r"\A\s*```[A-Za-z0-9_+#.-]*[ \t]*\r?\n(.*?)\r?\n?```\s*\Z", re.S)
RESERVED = re.compile(r"(?<![A-Za-z0-9_])\$?lc_")


class Rejected(Exception):
    pass


# ---------- submission ----------
def find_submission(res):
    direct = os.path.join(res, "submission.jsonl")
    if os.path.isfile(direct):
        return direct
    found = [os.path.join(d, f) for d, _, fs in os.walk(res) if "__MACOSX" not in d for f in fs if f == "submission.jsonl"]
    if len(found) == 1:
        return found[0]
    raise Rejected("the zip must hold exactly one submission.jsonl (found %d)" % len(found))


def read_submission(path):
    try:
        text = open(path, "rb").read().decode("utf-8")
    except UnicodeDecodeError:
        raise Rejected("submission.jsonl is not valid UTF-8")
    sub = {}
    for n, line in enumerate(text.splitlines(), 1):
        if not line.strip():
            continue
        try:
            rec = json.loads(line)
        except ValueError:
            raise Rejected("line %d is not valid JSON" % n)
        if not isinstance(rec, dict) or not isinstance(rec.get("task_id"), str) or not isinstance(rec.get("solution"), str):
            raise Rejected('line %d must be an object with string fields "task_id" and "solution"' % n)
        if rec["task_id"] in sub:
            raise Rejected("task_id %s appears twice (line %d)" % (rec["task_id"], n))
        sub[rec["task_id"]] = rec["solution"]
    return sub


def clean(pl, sol):
    """Spec section 6: remove one surrounding Markdown fence; for PHP, the <?php and ?> tags."""
    m = FENCE.match(sol)
    if m:
        sol = m.group(1)
    if pl == "php":
        sol = re.sub(r"\A\s*<\?php\b", "", sol)
        sol = re.sub(r"\?>\s*\Z", "", sol)
    return sol


# ---------- sandbox ----------
_uid = None
SWITCH = False      # True when solutions can run under their own uid (root with CAP_CHOWN and CAP_SETUID)
SECCOMP = False     # True when the seccomp filter can be loaded
DEADLINE = None     # time.time() after which tasks are no longer started


def can_switch_uid():
    """CodaBench runs the scorer as root, but its containers may lack the right to change owners or users."""
    d = tempfile.mkdtemp(prefix="lc_cap_")
    try:
        os.chown(d, UID_BASE, UID_BASE)
        r = subprocess.run([sys.executable, "-c", "pass"], preexec_fn=lambda: (os.setgid(UID_BASE), os.setuid(UID_BASE)),
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
        return r.returncode == 0
    except Exception:
        return False
    finally:
        shutil.rmtree(d, ignore_errors=True)


def can_seccomp():
    """Run a trivial program under the filter; False if the kernel or the container refuses it."""
    if not (LINUX and lc_sandbox):
        return False
    try:
        r = subprocess.run([sys.executable, "-I", "-c", "pass"], preexec_fn=lambda: lc_sandbox.install(os.getpid()),
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
        return r.returncode == 0
    except Exception:
        return False


def capabilities():
    try:
        return re.search(r"CapEff:\s*(\S+)", open("/proc/self/status").read()).group(1)
    except Exception:
        return "?"


def _init_worker(q, switch, seccomp, deadline):
    global _uid, SWITCH, SECCOMP, DEADLINE
    SWITCH, SECCOMP, DEADLINE = switch, seccomp, deadline
    _uid = UID_BASE + q.get() if switch else None


def _limits(cpu, mem, nproc, fsize, sandbox=False):
    def f():
        resource.setrlimit(resource.RLIMIT_CPU, (cpu, cpu))      # soft = hard: SIGKILL at the limit, no handler can stretch it
        resource.setrlimit(resource.RLIMIT_FSIZE, (fsize, fsize))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        if LINUX and mem:
            resource.setrlimit(resource.RLIMIT_AS, (mem, mem))
        if SWITCH:
            resource.setrlimit(resource.RLIMIT_NPROC, (nproc, nproc))
            os.setgroups([])
            os.setgid(_uid)
            os.setuid(_uid)
        if sandbox and SECCOMP:
            lc_sandbox.install(os.getpid())
    return f


def _kill(p):
    try:
        os.killpg(p.pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        pass
    if SWITCH:   # anything that left the process group but still runs under this worker's uid
        subprocess.run(["pkill", "-KILL", "-U", str(_uid)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    elif LINUX:  # same user as the scorer: kill what is left in the task's session
        for name in os.listdir("/proc"):
            if name.isdigit():
                try:
                    if int(open("/proc/%s/stat" % name).read().rsplit(")", 1)[1].split()[3]) == p.pid:
                        os.kill(int(name), signal.SIGKILL)
                except (OSError, ValueError, IndexError):
                    pass


def _spawn(cmd, d, timeout, limits):
    env = {"PATH": PATH, "HOME": d, "LANG": "C.UTF-8", "TMPDIR": d}
    p = subprocess.Popen(cmd, cwd=d, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, preexec_fn=limits, start_new_session=True, close_fds=True)
    try:
        rc = p.wait(timeout)
        timed_out = False
    except subprocess.TimeoutExpired:
        timed_out = True
        rc = None
    _kill(p)
    p.wait()
    return rc, timed_out


def run_task(task, solution):
    """Returns an outcome from OUTCOMES (never "missing" or "rejected")."""
    pl = task["pl"]
    d = tempfile.mkdtemp(prefix="lc_")
    try:
        with open(os.path.join(d, H.FILE[pl]), "w", encoding="utf-8") as f:
            f.write(H.harness(task, task["tests"], solution))
        res = os.path.join(d, "results.jsonl")       # the only file a solution may write; it cannot create others
        open(res, "w").close()
        os.chmod(res, 0o666)
        if SWITCH:
            for p in (d, os.path.join(d, H.FILE[pl]), res):
                os.chown(p, _uid, _uid)
        if pl == "c":
            rc, to = _spawn([H.CMD["c"], "-std=c17", "-O0", "-w", "-o", "main", "main.c", "-lm"], d,
                            COMPILE_TIMEOUT, _limits(int(COMPILE_TIMEOUT), COMPILE_MEM_MB << 20, max(NPROC, 64), 64 << 20))
            if to or rc != 0 or not os.path.exists(os.path.join(d, "main")):
                return "compile error"
            cmd = ["./main"]
        else:
            cmd = {"python": [H.CMD["python"], "-I", "main.py"],
                   "javascript": [H.CMD["javascript"], "--max-old-space-size=%d" % MEM_MB, "main.js"],
                   "php": [H.CMD["php"], "-d", "memory_limit=%dM" % MEM_MB, "main.php"],
                   "ruby": [H.CMD["ruby"], "--disable-gems", "main.rb"],
                   "lua": [H.CMD["lua"], "main.lua"]}[pl]
        mem = (NODE_AS_MB if pl == "javascript" else MEM_MB) << 20   # V8 reserves more address space than it uses
        rc, to = _spawn(cmd, d, TIMEOUT, _limits(CPU, mem, NPROC, 1 << 20, sandbox=True))
        if to:
            return "timeout (wall)"      # blocked or a busy machine: may be rerun once
        if rc in (-signal.SIGXCPU, -signal.SIGKILL):
            return "timeout"             # CPU limit: final, an infinite loop is never rerun
        if rc != 0:
            return "runtime error"
        path = os.path.join(d, "results.jsonl")
        lines = open(path, encoding="utf-8", errors="replace").read().splitlines() if os.path.exists(path) else []
        if len(lines) != len(task["tests"]):
            return "wrong answer"
        for line, t in zip(lines, task["tests"]):
            try:
                if not H.same(json.loads(line), t["out"], task["signature"]["returns"]):
                    return "wrong answer"
            except Exception:
                return "wrong answer"
        return "passed"
    except Exception as e:      # a scorer fault on one task must not stop the rest
        print("scorer error on %s: %s" % (task["task_id"], type(e).__name__), file=sys.stderr)
        return "runtime error"
    finally:
        shutil.rmtree(d, ignore_errors=True)


def _job(args):
    task, solution = args
    if DEADLINE and time.time() > DEADLINE:
        return task["task_id"], "timeout"
    return task["task_id"], run_task(task, solution)


def run_all(jobs, workers):
    if not jobs:
        return {}
    # fork on Linux: workers inherit the loaded scorer, so a solution that rewrites files on disk cannot change it
    ctx = mp.get_context("fork" if LINUX else "spawn")
    q = ctx.Queue()
    for i in range(workers):
        q.put(i)
    with cf.ProcessPoolExecutor(workers, mp_context=ctx, initializer=_init_worker, initargs=(q, SWITCH, SECCOMP, DEADLINE)) as ex:
        return dict(ex.map(_job, jobs, chunksize=4))


def close_dirs(*dirs):
    """Root only: keep the sandbox uids out of the reference and output folders."""
    for d in dirs:
        if os.path.isdir(d):
            try:
                os.chmod(d, 0o700)
            except OSError as e:
                print("warning: cannot close %s (%s)" % (d, e), file=sys.stderr)


def probe(ref_file):
    """Root only: check whether a solution could read the reference file (logged for the organizers)."""
    global _uid
    _uid = UID_BASE + WORKERS if SWITCH else None
    d = tempfile.mkdtemp(prefix="lc_probe_")
    try:
        if SWITCH:
            os.chown(d, _uid, _uid)
        rc, _ = _spawn([sys.executable, "-I", "-c", "import os; os.chmod(%r, 0o644); open(%r).read(1)" % (ref_file, ref_file)],
                       d, 5, _limits(2, 0, NPROC, 1 << 20, sandbox=True))
    finally:
        shutil.rmtree(d, ignore_errors=True)
        _uid = None
    if rc == 0:
        print("WARNING: a solution can read the reference data", file=sys.stderr)


def reap_strays():
    """Root without uid switching: kill every process that is not the scorer, one of its ancestors, or pid 1,
    so nothing a solution left running can touch the output after scoring."""
    keep, pid = {1}, os.getpid()
    while pid > 1:
        keep.add(pid)
        try:
            pid = int(open("/proc/%d/stat" % pid).read().rsplit(")", 1)[1].split()[1])
        except (OSError, ValueError, IndexError):
            break
    n = 0
    for name in os.listdir("/proc"):
        if name.isdigit() and int(name) not in keep:
            try:
                os.kill(int(name), signal.SIGKILL)
                n += 1
            except (ProcessLookupError, PermissionError):
                pass
    return n


# ---------- scores ----------
def pct(xs):
    return round(100.0 * sum(xs) / len(xs), 2) if xs else 0.0


def scores(tasks, outcome):
    """Spec section 8: Pass@1 over all tasks (score), then Pass@1 per Joshi class and per PL."""
    ok = {t["task_id"]: outcome[t["task_id"]] == "passed" for t in tasks}
    s = {"score": pct(list(ok.values()))}
    for k in sorted({t["tier"] for t in tasks if "tier" in t}):     # the public trial reference has no tier
        s["tier_%d" % k] = pct([ok[t["task_id"]] for t in tasks if t.get("tier") == k])
    for pl in H.PLS:
        s[pl] = pct([ok[t["task_id"]] for t in tasks if t["pl"] == pl])
    return s


def detailed_html(tasks, outcome, phase):
    counts = {o: sum(1 for t in tasks if outcome[t["task_id"]] == o) for o in OUTCOMES}
    rows = "\n".join("<tr><td>%s</td><td class=\"%s\">%s</td></tr>" % (html.escape(t["task_id"]), "ok" if outcome[t["task_id"]] == "passed" else "bad",
                                                                     outcome[t["task_id"]]) for t in tasks)
    summ = "".join("<tr><td>%s</td><td>%d</td></tr>" % (o, counts[o]) for o in OUTCOMES)
    return ("<!doctype html><html><head><meta charset=\"utf-8\"><title>LangCode 2027 Task 1: %s results</title>"
            "<style>body{font-family:sans-serif;margin:16px}table{border-collapse:collapse;margin-bottom:16px}"
            "td{border:1px solid #ccc;padding:2px 8px}.ok{color:#176b2c}.bad{color:#a12020}</style></head><body>"
            "<h2>Outcome per task (%s phase)</h2><table>%s</table><table><tr><td><b>task_id</b></td><td><b>outcome</b></td></tr>%s</table>"
            "</body></html>" % (html.escape(phase), html.escape(phase), summ, rows))


def main(inp, out):
    ref, res = os.path.join(inp, "ref"), os.path.join(inp, "res")
    ref_file = os.path.join(ref, "reference.jsonl")
    tasks = [json.loads(l) for l in open(ref_file, encoding="utf-8") if l.strip()]
    phase = json.load(open(os.path.join(ref, "phase.json")))
    os.makedirs(out, exist_ok=True)
    global SWITCH, SECCOMP, DEADLINE
    start = time.time()
    DEADLINE = start + BUDGET
    SECCOMP = can_seccomp()
    if LINUX:
        print("sandbox: seccomp %s, capabilities %s" % ("on" if SECCOMP else "OFF", capabilities()), file=sys.stderr)
    if ROOT:
        SWITCH = can_switch_uid()
        close_dirs(ref, out, res)
        if not SWITCH:
            try:
                os.chmod(ref_file, 0)
            except OSError:
                pass
            print("note: root without the right to switch users, so solutions run as root (limits still apply)", file=sys.stderr)
        probe(ref_file)
    else:
        print("note: not running as root, so solutions run as the current user without uid separation", file=sys.stderr)
    try:
        sub = read_submission(find_submission(res))
    except Rejected as e:
        print("Submission rejected: %s" % e)
        print("Submission rejected: %s" % e, file=sys.stderr)
        sys.exit(1)

    known = {t["task_id"] for t in tasks}
    outcome, jobs = {}, []
    for t in tasks:
        sol = sub.get(t["task_id"])
        if sol is None or not sol.strip():
            outcome[t["task_id"]] = "missing"
            continue
        sol = clean(t["pl"], sol)
        if len(sol.encode("utf-8")) > MAX_SOLUTION or RESERVED.search(sol):
            outcome[t["task_id"]] = "rejected"
            continue
        jobs.append((t, sol))
    t0 = time.time()
    outcome.update(run_all(jobs, WORKERS))
    # a timeout can come from a busy machine: rerun those tasks once with half the workers
    again = [j for j in jobs if outcome[j[0]["task_id"]] == "timeout (wall)"]
    rerun = 0 < len(again) <= RETRY_MAX and time.time() < DEADLINE - 60
    if rerun:
        outcome.update(run_all(again, max(1, WORKERS // 2)))
    outcome = {k: ("timeout" if v == "timeout (wall)" else v) for k, v in outcome.items()}
    if ROOT and not SWITCH and LINUX:
        reap_strays()
    for name in os.listdir(out):          # nothing a solution planted there reaches CodaBench
        p = os.path.join(out, name)
        shutil.rmtree(p, ignore_errors=True) if os.path.isdir(p) and not os.path.islink(p) else os.remove(p)
    s = scores(tasks, outcome)
    json.dump(s, open(os.path.join(out, "scores.json"), "w"), indent=1)
    if phase.get("detailed_results"):
        open(os.path.join(out, "detailed_results.html"), "w", encoding="utf-8").write(detailed_html(tasks, outcome, phase.get("phase", "")))
    print("Scored %d tasks (%d submitted, %d unknown task_ids ignored, %d timeouts rerun) in %.1f s with %d workers."
          % (len(tasks), sum(1 for k in sub if k in known), sum(1 for k in sub if k not in known),
             len(again) if rerun else 0, time.time() - t0, WORKERS))


def check(path, public=None):
    """Applies the rejection rules of spec section 6 without running anything; with the public file,
    also lists missing, unknown and rejected tasks. Exit status 1 if CodaBench would reject the file."""
    tmp = None
    try:
        if zipfile.is_zipfile(path):
            tmp = tempfile.mkdtemp(prefix="lc_check_")
            zipfile.ZipFile(path).extractall(tmp)
            path = tmp
        sub = read_submission(find_submission(path) if os.path.isdir(path) else path)
    except Rejected as e:
        print("Submission rejected: %s" % e)
        sys.exit(1)
    finally:
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
    print("Format OK: %d solutions." % len(sub))
    if public:
        tasks = {json.loads(l)["task_id"]: json.loads(l) for l in open(public, encoding="utf-8") if l.strip()}
        missing = [k for k in tasks if not (sub.get(k) or "").strip()]
        unknown = [k for k in sub if k not in tasks]
        too_long = [k for k in sub if k in tasks and len(clean("", sub[k]).encode("utf-8")) > MAX_SOLUTION]
        reserved = [k for k in sub if k in tasks and RESERVED.search(clean("", sub[k]))]
        for name, ids in (("missing (scored as failed)", missing), ("unknown task_id (ignored)", unknown),
                          ("over 20 KB (rejected task)", too_long), ("uses an lc_ name (rejected task)", reserved)):
            print("%-34s %d%s" % (name + ":", len(ids), ("  e.g. " + ", ".join(ids[:5])) if ids else ""))


if __name__ == "__main__":
    a = sys.argv[1:]
    if a and a[0] == "--check":
        check(a[1], a[2] if len(a) > 2 else None)
    else:
        main(a[0] if a else "/app/input", a[1] if len(a) > 1 else "/app/output")
