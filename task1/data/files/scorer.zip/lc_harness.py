"""LangCode 2027 Task 1: harness generator, prompt renderer, stub builder and checker.

One row = one task: {"pl", "entry", "signature": {"args": [[name, type]], "returns": type},
"description_en", "example": {"in", "out"}, "tests": [{"in", "out"} x5], "canonical_solution"}.
Types: int, bool, str, list[int], list[bool], list[str] (spec section 4).
The harness writes one JSON value per line to results.jsonl, which must already exist: it is opened
without creating it ("r+"), so the scorer's sandbox can refuse every file creation. The checker compares outside the
solution's process (spec section 7). Toolchain commands can be changed with LC_<PL> env variables.
"""
import json, os, re, resource, shutil, subprocess, sys, tempfile, time

PLS = ["python", "javascript", "c", "php", "ruby", "lua"]
TYPES = {"int", "bool", "str", "list[int]", "list[bool]", "list[str]"}
CMD = {
    "python": os.environ.get("LC_PYTHON", "python3"),
    "javascript": os.environ.get("LC_NODE", "node"),
    "c": os.environ.get("LC_CC", "cc"),
    "php": os.environ.get("LC_PHP", next((p for p in ("/opt/homebrew/opt/php/bin/php", "/usr/local/opt/php/bin/php") if os.path.exists(p)), "php")),
    "ruby": os.environ.get("LC_RUBY", next((p for p in ("/opt/homebrew/opt/ruby/bin/ruby", "/usr/local/opt/ruby/bin/ruby") if os.path.exists(p)), "ruby")),
    "lua": os.environ.get("LC_LUA", "lua"),
}
FILE = {"python": "main.py", "javascript": "main.js", "c": "main.c", "php": "main.php", "ruby": "main.rb", "lua": "main.lua"}

def inner(t): return t[5:-1]
def is_list(t): return t.startswith("list[")

# ---------- literals ----------
def lit(pl, v, t):
    if is_list(t):
        items = ", ".join(lit(pl, x, inner(t)) for x in v)
        return {"python": "[%s]", "javascript": "[%s]", "php": "[%s]", "ruby": "[%s]", "lua": "{%s}"}[pl] % items
    if t == "bool":
        return ("True" if v else "False") if pl == "python" else ("true" if v else "false")
    if t == "str":
        if pl in ("php", "ruby"):
            return "'" + v.replace("\\", "\\\\").replace("'", "\\'") + "'"
        return json.dumps(v)          # valid Python, JS, C and Lua literal for printable ASCII
    return str(int(v))

# ---------- C types ----------
C_SCALAR = {"int": "long long", "bool": "bool", "str": "const char *"}
C_ELEM = {"int": "long long", "bool": "bool", "str": "const char *"}
def c_params(sig):
    ps = []
    for name, t in sig["args"]:
        if is_list(t):
            e = inner(t)
            ps.append(("const char *const *%s" % name) if e == "str" else ("const %s *%s" % (C_ELEM[e], name)))
            ps.append("int %s_len" % name)
        else:
            ps.append("%s%s" % (C_SCALAR[t], name) if t == "str" else "%s %s" % (C_SCALAR[t], name))
    if is_list(sig["returns"]): ps.append("int *out_len")
    return ps
def c_ret(t):
    if is_list(t): return {"int": "long long *", "bool": "bool *", "str": "char **"}[inner(t)]
    return {"int": "long long ", "bool": "bool ", "str": "char *"}[t]

# ---------- signatures, prompts, stubs ----------
def signature_line(pl, entry, sig):
    args = sig["args"]
    if pl == "python":
        return "def %s(%s) -> %s:" % (entry, ", ".join("%s: %s" % (n, t) for n, t in args), sig["returns"])
    if pl == "javascript":
        return "function %s(%s) {" % (entry, ", ".join(n for n, _ in args))
    if pl == "c":
        return "%s%s(%s) {" % (c_ret(sig["returns"]), entry, ", ".join(c_params(sig)))
    if pl == "php":
        ph = {"int": "int", "bool": "bool", "str": "string"}
        r = "array" if is_list(sig["returns"]) else ph[sig["returns"]]
        return "function %s(%s): %s {" % (entry, ", ".join(("array" if is_list(t) else ph[t]) + " $" + n for n, t in args), r)
    if pl == "ruby":
        return "def %s(%s)" % (entry, ", ".join(n for n, _ in args))
    if pl == "lua":
        return "function %s(%s)" % (entry, ", ".join(n for n, _ in args))

def example_line(pl, entry, sig, ex):
    a = ", ".join(lit("javascript" if pl == "c" else pl, v, t) for v, (_, t) in zip(ex["in"], sig["args"]))
    out = lit("javascript" if pl == "c" else pl, ex["out"], sig["returns"])
    if pl == "c": return "Example: %s(%s) returns %s" % (entry, a, out)
    return "Example: %s(%s) == %s" % (entry, a, out)

def render_prompt(row):
    pl, entry, sig = row["pl"], row["entry"], row["signature"]
    lines = row["description_en"].split("\n") + ["", example_line(pl, entry, sig, row["example"])]
    if pl == "python":
        body = "\n".join(("    " + l) if l else "" for l in lines)
        return signature_line(pl, entry, sig) + '\n    """\n' + body + '\n    """\n'
    if pl == "ruby": com = [("# " + l).rstrip() for l in lines]
    elif pl == "lua": com = [("-- " + l).rstrip() for l in lines]
    else: com = ["/**"] + [(" * " + l).rstrip() for l in lines] + [" */"]
    return "\n".join(com) + "\n" + signature_line(pl, entry, sig) + "\n"

def stub_solution(pl, entry, sig, kind="zero"):
    """A solution with the official signature that returns a constant (0, false, "", empty list)."""
    r = sig["returns"]
    if pl == "c":
        if is_list(r): body = "    *out_len = 0;\n    return malloc(sizeof(%s));" % c_ret(r).rstrip(" *").replace("char", "char *")
        elif r == "str": body = '    char *lc_s = malloc(1); lc_s[0] = 0; return lc_s;'
        elif r == "bool": body = "    return false;"
        else: body = "    return 0;"
        return "#include <stdlib.h>\n#include <stdbool.h>\n" + signature_line(pl, entry, sig) + "\n" + body + "\n}\n"
    val = {"python": {"int": "0", "bool": "False", "str": '""', "list": "[]"},
           "javascript": {"int": "0", "bool": "false", "str": '""', "list": "[]"},
           "php": {"int": "0", "bool": "false", "str": '""', "list": "[]"},
           "ruby": {"int": "0", "bool": "false", "str": '""', "list": "[]"},
           "lua": {"int": "0", "bool": "false", "str": '""', "list": "{}"}}[pl]["list" if is_list(r) else r]
    if pl == "python": return signature_line(pl, entry, sig) + "\n    return %s\n" % val
    if pl in ("javascript", "php"): return signature_line(pl, entry, sig) + "\n    return %s;\n}\n" % val
    return signature_line(pl, entry, sig) + "\n  return %s\nend\n" % val

# ---------- harness ----------
def _c_value_writer(t):
    if t == "int": return 'fprintf(lc_out, "%lld", (long long)(V));'
    if t == "bool": return 'fputs((V) ? "true" : "false", lc_out);'
    if t == "str": return 'lc_str(V);'

def harness(row, cases, solution):
    pl, e, sig = row["pl"], row["entry"], row["signature"]
    calls = [] if pl == "c" else [", ".join(lit(pl, v, t) for v, (_, t) in zip(c["in"], sig["args"])) for c in cases]
    R = sig["returns"]
    if pl == "python":
        pre = "import json as lc_json\nlc_open = open\n"
        post = "\nwith lc_open('results.jsonl', 'r+') as lc_f:\n" + "".join(
            "    lc_f.write(lc_json.dumps(%s(%s)) + '\\n')\n" % (e, c) for c in calls)
        return pre + solution + "\n" + post
    if pl == "javascript":
        pre = "const lc_fs = require('fs'); const lc_JSON = JSON;\n"
        post = "\nconst lc_res = [];\n" + "".join("lc_res.push(lc_JSON.stringify(%s(%s)));\n" % (e, c) for c in calls) + \
               "lc_fs.writeFileSync('results.jsonl', lc_res.join('\\n') + '\\n', {flag: 'r+'});\n"
        return pre + solution + "\n" + post
    if pl == "php":
        sol = re.sub(r"^\s*<\?php\s*", "", solution)
        norm = "array_values(%s)" if is_list(R) else "%s"
        post = "\n$lc_f = fopen('results.jsonl', 'r+');\n" + "".join(
            "fwrite($lc_f, json_encode(%s) . \"\\n\");\n" % (norm % ("%s(%s)" % (e, c))) for c in calls) + "fclose($lc_f);\n"
        return "<?php\n" + sol + "\n" + post
    if pl == "ruby":
        post = "\nrequire 'json'\nFile.open('results.jsonl', 'r+') do |lc_f|\n" + "".join(
            "  lc_f.puts(JSON.generate(%s(%s)))\n" % (e, c) for c in calls) + "end\n"
        return solution + "\n" + post
    if pl == "lua":
        pre = ("local lc_type, lc_mtype, lc_format, lc_floor, lc_concat, lc_open, lc_tostring = "
               "type, math.type, string.format, math.floor, table.concat, io.open, tostring\n"
               "local function lc_str(s)\n  if lc_type(s) ~= 'string' then return 'null' end\n"
               "  return '\"' .. s:gsub('\\\\', '\\\\\\\\'):gsub('\"', '\\\\\"') .. '\"'\nend\n"
               "local function lc_num(v)\n  if lc_type(v) ~= 'number' then return 'null' end\n"
               "  if lc_mtype(v) == 'integer' then return lc_format('%d', v) end\n"
               "  if v == lc_floor(v) and v > -1e15 and v < 1e15 then return lc_format('%.1f', v) end\n"
               "  return lc_format('%.17g', v)\nend\n"
               "local function lc_bool(v)\n  if lc_type(v) ~= 'boolean' then return 'null' end\n  return lc_tostring(v)\nend\n"
               "local function lc_list(t, f)\n  if lc_type(t) ~= 'table' then return 'null' end\n"
               "  local o = {}\n  for i = 1, #t do o[i] = f(t[i]) end\n  return '[' .. lc_concat(o, ',') .. ']'\nend\n")
        scal = {"int": "lc_num", "bool": "lc_bool", "str": "lc_str"}
        enc = ("function(v) return lc_list(v, %s) end" % scal[inner(R)]) if is_list(R) else scal[R]
        post = "\nlocal lc_enc = %s\nlocal lc_f = lc_open('results.jsonl', 'r+')\n" % enc + "".join(
            "lc_f:write(lc_enc(%s(%s)) .. '\\n')\n" % (e, c) for c in calls) + "lc_f:close()\n"
        return pre + solution + "\n" + post
    if pl == "c":
        decl, body = [], []
        for i, c in enumerate(cases):
            args = []
            for j, (v, (n, t)) in enumerate(zip(c["in"], sig["args"])):
                if is_list(t):
                    if not v: args += ["NULL", "0"]; continue
                    el = inner(t); nm = "lc_a%d_%d" % (i, j)
                    ctype = {"int": "const long long", "bool": "const bool", "str": "const char *const"}[el]
                    decl.append("static %s %s[] = {%s};" % (ctype, nm, ", ".join(lit("javascript", x, el) for x in v)))
                    args += [nm, str(len(v))]
                else:
                    args.append(lit("javascript", v, t))
            if is_list(R):
                el = inner(R)
                body.append("    { int lc_n = -1; %sr = %s(%s); fputc('[', lc_out); for (int k = 0; k < lc_n; k++) { if (k) fputc(',', lc_out); %s } fputs(\"]\\n\", lc_out); }"
                            % (c_ret(R), e, ", ".join(args + ["&lc_n"]), _c_value_writer(el).replace("V", "r[k]")))
            else:
                body.append("    { %sr = %s(%s); %s fputc('\\n', lc_out); }" % (c_ret(R), e, ", ".join(args), _c_value_writer(R).replace("V", "r")))
        pre = "#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n#include <stdbool.h>\n#include <math.h>\n"
        tail = ("\nstatic FILE *lc_out;\nstatic void lc_str(const char *s) {\n    if (!s) { fputs(\"null\", lc_out); return; }\n"
                "    fputc('\"', lc_out);\n    for (; *s; s++) { if (*s == '\"' || *s == '\\\\') fputc('\\\\', lc_out); fputc(*s, lc_out); }\n"
                "    fputc('\"', lc_out);\n}\n" + "\n".join(decl) + "\nint main(void) {\n    lc_out = fopen(\"results.jsonl\", \"r+\");\n"
                + "\n".join(body) + "\n    fclose(lc_out);\n    return 0;\n}\n")
        return pre + solution + "\n" + tail

# ---------- comparison (spec section 7) ----------
def same(got, exp, t):
    if is_list(t):
        return isinstance(got, list) and len(got) == len(exp) and all(same(g, x, inner(t)) for g, x in zip(got, exp))
    if t == "bool": return isinstance(got, bool) and got == exp
    if t == "str": return isinstance(got, str) and got == exp
    if t == "int":
        if isinstance(got, bool) or not isinstance(got, (int, float)): return False
        return float(got).is_integer() and int(got) == exp

def _limits():
    resource.setrlimit(resource.RLIMIT_CPU, (2, 2))
    resource.setrlimit(resource.RLIMIT_FSIZE, (1 << 20, 1 << 20))

def run(row, cases, solution, timeout=5.0, keep=False):
    """Returns (ok_list, info). ok_list has one bool per case; info explains failures."""
    pl = row["pl"]
    d = tempfile.mkdtemp(prefix="lc_")
    try:
        src = harness(row, cases, solution)
        open(os.path.join(d, FILE[pl]), "w").write(src)
        open(os.path.join(d, "results.jsonl"), "w").close()
        t0 = time.perf_counter()
        if pl == "c":
            cc = subprocess.run([CMD["c"], "-std=c17", "-O0", "-w", "-o", "main", "main.c", "-lm"], cwd=d, capture_output=True, text=True, errors="replace", timeout=20)
            if cc.returncode: return [False] * len(cases), {"error": "compile error", "detail": cc.stderr[-600:]}
            cmd = ["./main"]
        else:
            cmd = {"python": [CMD["python"], "main.py"], "javascript": [CMD["javascript"], "main.js"], "php": [CMD["php"], "main.php"],
                   "ruby": [CMD["ruby"], "--disable-gems", "main.rb"], "lua": [CMD["lua"], "main.lua"]}[pl]
        t1 = time.perf_counter()
        try:
            p = subprocess.run(cmd, cwd=d, capture_output=True, text=True, errors="replace", timeout=timeout, preexec_fn=_limits)
        except subprocess.TimeoutExpired:
            return [False] * len(cases), {"error": "timeout"}
        t2 = time.perf_counter()
        path = os.path.join(d, "results.jsonl")
        lines = open(path, encoding="utf-8", errors="replace").read().splitlines() if os.path.exists(path) else []   # invalid bytes from a broken solution must not crash the scorer
        oks, bad = [], None
        for i, c in enumerate(cases):
            try:
                ok = i < len(lines) and same(json.loads(lines[i]), c["out"], row["signature"]["returns"])
            except Exception:
                ok = False
            oks.append(ok)
            if not ok and bad is None:
                bad = {"case": i, "input": c["in"], "expected": c["out"], "got": lines[i] if i < len(lines) else None}
        info = {"run_ms": round(1000 * (t2 - t1), 1), "compile_ms": round(1000 * (t1 - t0), 1)}
        if len(lines) != len(cases): info["error"] = "runtime error" if p.returncode else "missing or extra result lines"
        if bad: info["first_failure"] = bad
        if p.returncode or (not all(oks)): info["stderr"] = p.stderr[-600:]
        return oks, info
    finally:
        if not keep: shutil.rmtree(d, ignore_errors=True)

def check_row(row, solution=None):
    """Full check of one row: solution passes example + 5 tests, stub fails a test."""
    sol = row["canonical_solution"] if solution is None else solution
    cases = [row["example"]] + row["tests"]
    oks, info = run(row, cases, sol)
    soks, sinfo = run(row, row["tests"], stub_solution(row["pl"], row["entry"], row["signature"]))
    stub_ran = "error" not in sinfo or sinfo.get("error") not in ("compile error",)
    return {"pass": all(oks), "cases_passed": sum(oks), "info": info,
            "stub_fails_a_test": not all(soks), "stub_signature_valid": stub_ran and sinfo.get("error") != "runtime error" or not all(soks),
            "stub_info": sinfo if sinfo.get("error") else None}

if __name__ == "__main__":
    # usage: python3 lc_harness.py rows.jsonl [--solution-field blind_solution]
    path = sys.argv[1]; field = sys.argv[sys.argv.index("--solution-field") + 1] if "--solution-field" in sys.argv else "canonical_solution"
    n = ok = 0
    for line in open(path):
        if not line.strip(): continue
        row = json.loads(line); n += 1
        r = check_row(row, row.get(field))
        ok += r["pass"] and r["stub_fails_a_test"]
        status = "PASS" if r["pass"] and r["stub_fails_a_test"] else "FAIL"
        print(json.dumps({"id": row.get("task_id") or row.get("seed_id") or row.get("cand_id"), "pl": row["pl"], "status": status, **r}))
    print(f"# {ok}/{n} rows pass", file=sys.stderr)
