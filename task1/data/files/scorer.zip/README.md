# LangCode 2027 Shared Task 1: scorer

The same scoring program that runs on CodaBench. It needs Python 3.9+, and the toolchains of the
languages you score (python3, node, gcc, php, ruby, lua). On Linux it runs each solution under the
same sandbox and limits as CodaBench.

Check the format of a submission before uploading it (no code is run):

    python3 score.py --check submission.zip dev.jsonl

Score a submission on the trial set (the trial set ships with all its tests):

    mkdir -p run/res && cp submission.jsonl run/res/ && cp -r reference_trial run/ref
    python3 score.py run out
    cat out/scores.json

`submission.jsonl` has one line per task: {"task_id": "T1-trial-0001", "solution": "..."}.
Questions: the Forum of the CodaBench competition, https://www.codabench.org/competitions/18470/
