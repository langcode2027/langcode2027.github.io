"""Seccomp filter for running a solution (Linux, x86_64 and aarch64).

install(pid) is called in the child between fork and exec. It sets no_new_privs and loads a BPF filter
that makes these system calls fail with EPERM: creating processes (fork, vfork, clone without
CLONE_THREAD; clone3 fails with ENOSYS so libc falls back to clone), creating files, folders or links
(open/openat with O_CREAT or O_TMPFILE, creat, mkdir, link, symlink, rename, mknod, memfd_create;
openat2 fails with ENOSYS), opening sockets, signalling any process but itself, changing file modes or
owners, tracing or reading other processes, and mounting,
namespaces, modules, kexec, reboot, bpf, perf, io_uring, keyrings and userfaultfd. Threads, files in the
working directory and everything a language runtime needs at start still work. Calls from another ABI
(i386, x32) are refused. No privileges are needed.
"""
import ctypes, platform, struct

ARCH = {"x86_64": 0xC000003E, "aarch64": 0xC00000B7}
NR = {
    "x86_64": {"fork": 57, "vfork": 58, "clone": 56, "clone3": 435, "kill": 62, "tkill": 200, "tgkill": 234,
               "socket": 41, "ptrace": 101, "process_vm_readv": 310, "process_vm_writev": 311,
               "mount": 165, "umount2": 166, "chroot": 161, "pivot_root": 155, "unshare": 272, "setns": 308,
               "reboot": 169, "kexec_load": 246, "kexec_file_load": 320, "init_module": 175, "finit_module": 313,
               "delete_module": 176, "bpf": 321, "perf_event_open": 298, "io_uring_setup": 425,
               "keyctl": 250, "add_key": 248, "request_key": 249, "userfaultfd": 323,
               "chmod": 90, "fchmod": 91, "fchmodat": 268, "fchmodat2": 452,
               "chown": 92, "fchown": 93, "lchown": 94, "fchownat": 260,
               "open": 2, "openat": 257, "openat2": 437, "creat": 85, "mkdir": 83, "mkdirat": 258,
               "link": 86, "linkat": 265, "symlink": 88, "symlinkat": 266, "rename": 82, "renameat": 264,
               "renameat2": 316, "mknod": 133, "mknodat": 259, "memfd_create": 319},
    "aarch64": {"clone": 220, "clone3": 435, "kill": 129, "tkill": 130, "tgkill": 131,
                "socket": 198, "ptrace": 117, "process_vm_readv": 270, "process_vm_writev": 271,
                "mount": 40, "umount2": 39, "chroot": 51, "pivot_root": 41, "unshare": 97, "setns": 268,
                "reboot": 142, "kexec_load": 104, "kexec_file_load": 294, "init_module": 105, "finit_module": 273,
                "delete_module": 106, "bpf": 280, "perf_event_open": 241, "io_uring_setup": 425,
                "keyctl": 219, "add_key": 217, "request_key": 218, "userfaultfd": 282,
                "fchmod": 52, "fchmodat": 53, "fchmodat2": 452, "fchown": 55, "fchownat": 54,
                "openat": 56, "openat2": 437, "mkdirat": 34, "linkat": 37, "symlinkat": 36,
                "renameat2": 276, "mknodat": 33, "memfd_create": 279},
}
SPECIAL = {"clone", "clone3", "kill", "tkill", "tgkill", "open", "openat", "openat2"}
CREATE = 0x40 | 0x400000                                   # O_CREAT | __O_TMPFILE (same on x86_64 and aarch64)
OFF_ARG1, OFF_ARG2 = 24, 32
CLONE_THREAD = 0x10000
LD, JEQ, JSET, RET = 0x20, 0x15, 0x45, 0x06
ALLOW, EPERM, ENOSYS = 0x7FFF0000, 0x00050000 | 1, 0x00050000 | 38
OFF_NR, OFF_ARCH, OFF_ARG0 = 0, 4, 16


def _assemble(prog):
    """prog: list of (code, jt, jf, k) where jt/jf may be label names; labels are ("label", name)."""
    pos, out = {}, []
    for item in prog:
        if item[0] == "label":
            pos[item[1]] = len(out)
        else:
            out.append(item)
    code = []
    for i, (c, jt, jf, k) in enumerate(out):
        jt = pos[jt] - i - 1 if isinstance(jt, str) else jt
        jf = pos[jf] - i - 1 if isinstance(jf, str) else jf
        code.append(struct.pack("HBBI", c, jt, jf, k & 0xFFFFFFFF))
    return b"".join(code), len(code)


def build(pid, machine=None):
    machine = machine or platform.machine()
    if machine not in ARCH:
        return None
    nr = NR[machine]
    p = [(LD, 0, 0, OFF_ARCH), (JEQ, 1, 0, ARCH[machine]), (RET, 0, 0, EPERM), (LD, 0, 0, OFF_NR)]
    if machine == "x86_64":
        p.append((JSET, "deny", 0, 0x40000000))                    # x32 ABI
    for name, n in nr.items():
        if name not in SPECIAL:
            p.append((JEQ, "deny", 0, n))
    # BPF jumps only go forward, so the shared returns come last
    p += [(JEQ, "clone", 0, nr["clone"]), (JEQ, "enosys", 0, nr["clone3"]), (JEQ, "kill", 0, nr["kill"]),
          (JEQ, "tgkill", 0, nr["tgkill"]), (JEQ, "deny", 0, nr["tkill"]),
          (JEQ, "openat", 0, nr["openat"]), (JEQ, "enosys", 0, nr["openat2"])]
    if "open" in nr:
        p.append((JEQ, "open", 0, nr["open"]))
    p += [(RET, 0, 0, ALLOW),
          ("label", "openat"), (LD, 0, 0, OFF_ARG2), (JSET, "deny", "allow", CREATE),
          ("label", "open"), (LD, 0, 0, OFF_ARG1), (JSET, "deny", "allow", CREATE),
          ("label", "clone"), (LD, 0, 0, OFF_ARG0), (JSET, "allow", "deny", CLONE_THREAD),
          ("label", "kill"), (LD, 0, 0, OFF_ARG0), (JEQ, "allow", 0, pid), (JEQ, "allow", "deny", 0),
          ("label", "tgkill"), (LD, 0, 0, OFF_ARG0), (JEQ, "allow", "deny", pid),
          ("label", "enosys"), (RET, 0, 0, ENOSYS),
          ("label", "deny"), (RET, 0, 0, EPERM),
          ("label", "allow"), (RET, 0, 0, ALLOW)]
    return _assemble(p)


class _Prog(ctypes.Structure):
    _fields_ = [("len", ctypes.c_ushort), ("filter", ctypes.c_void_p)]


def install(pid):
    """Load the filter into the calling process. Raises OSError if the kernel refuses."""
    built = build(pid)
    if built is None:
        raise OSError("seccomp: unsupported machine %s" % platform.machine())
    code, n = built
    libc = ctypes.CDLL(None, use_errno=True)
    buf = ctypes.create_string_buffer(code, len(code))
    prog = _Prog(n, ctypes.cast(buf, ctypes.c_void_p))
    if libc.prctl(38, 1, 0, 0, 0) != 0:                               # PR_SET_NO_NEW_PRIVS
        raise OSError(ctypes.get_errno(), "prctl(PR_SET_NO_NEW_PRIVS)")
    if libc.prctl(22, 2, ctypes.byref(prog), 0, 0) != 0:              # PR_SET_SECCOMP, SECCOMP_MODE_FILTER
        raise OSError(ctypes.get_errno(), "prctl(PR_SET_SECCOMP)")
